<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "dc heroes";
$connection = new mysqli ($servername, $username, $password, $dbname) or die ($connection->error);
?>