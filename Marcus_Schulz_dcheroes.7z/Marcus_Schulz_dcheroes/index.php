<?php

include "databaseConnection.php";

$reviews = array();

if (isset($_POST['submitComment'])) 
{
	//die("current line s " . __LINE__);
    $comment = $_POST['submitComment'];
    $IDhero = $_POST['heroId'];
	$insertCommentQuery = "INSERT INTO `rating` (`ratingId`, `ratingReview`, `heroId`, `ratingDate`) VALUES (NULL, '$comment', '$IDhero', NOW())";
	$commentInformation = $connection->query($insertCommentQuery) or die($connection->error);
}

if(isset($_GET["teamCat"])){
	$teamId = $_GET["teamCat"];
}
else 
{
	$teamId = 4; 
}

if(isset($_GET["heroCat"])){
	$heroId = $_GET["heroCat"];
}
else
{
	$heroId = 0;
}

$teams = [];
$information = [];
$heroinformation = [];

$selectTeamsQuery = "SELECT teamId, teamName, teamImage, COUNT(heroId) from team NATURAL JOIN hero GROUP BY teamID";
$selectInformationQuery = " SELECT * FROM `hero` WHERE teamId=" . $teamId ."";
$selectReviewQuery = "SELECT * FROM `rating` where heroId=". $heroId .";";

if($heroId == 0)
{
	$selectHeroInformationQuery = " SELECT * FROM `hero` ORDER BY RAND() LIMIT 1";
}
else
{
	$selectHeroInformationQuery = " SELECT * FROM `hero` WHERE heroId=" . $heroId ."";
}

$results = mysqli_query ($connection,$selectTeamsQuery);
$resultsinformation = mysqli_query($connection,$selectInformationQuery);
$resultsheroinformation = mysqli_query($connection,$selectHeroInformationQuery);
$resultsreviewinformation = mysqli_query($connection,$selectReviewQuery);

$reviews = $resultsreviewinformation;

while ($row = mysqli_fetch_assoc($results))
{
    $teams[] = $row;
}

while ($row = mysqli_fetch_assoc($resultsinformation))
{
    $information[] = $row;
}

$heroinformation = mysqli_fetch_assoc($resultsheroinformation);

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta name="description" content="DC Heroes">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title>DC Heroes</title>
	<link rel="shortcut icon" type="image/jpg" href="images/logo.jpg"/>
</head>
<body>

<header id="header">
	<a href="index.php"><h1 id="dclogo_text">HEROES</h1></a>
	<a href="index.php"><img id="dclogo" src="images/dc2.jpg"></a>	
</header>
	
<div id="main-container">

	<div id="main-left">
		<nav id="nav">
			<ul> 
				<li id="teams"> TEAMS </li>
					<?php 
						foreach($teams as $key => $team) 
						{
					?>
						<li class="navtext"><a href="index.php?teamCat=<?php echo $team['teamId']; ?>"><?php echo '<img class="teampicture" src="'.$team['teamImage'] . '">' . '<div class="Members">' . 'Members: ' . $team['COUNT(heroId)'] . '</div>' .  '<div class="TeamName">' . $team['teamName'] . '</div>' . '<br />' ; ?></a></li>
					<?php
						}
					?>
			</ul>
		</nav>
	</div>

	<div id="main-center">
	<?php 
		foreach($information as $key => $informations) 
		{ 
		echo '<div class="heroback">';
	?>
		<img class="image" src="<?php echo $informations ['heroImage']; ?>" />
		<h2 class="heroName"> <?php echo $informations ['heroName']; ?> </h2>
		<h5 class="heroSmallDescription"><?php echo $informations ['heroSmallDescription']; ?> </h5>
		<a href="index.php?teamCat=<?php echo $informations['teamId']; ?>&heroCat=<?php echo $informations['heroId'];?>"><button class="order"> More Info </button></a>
	<?php
		echo '</div>';
		}
	?>
	</div>

	<div id="main-right">
		<?php
		if(!empty($heroinformation))
		{
			?>
			<h2 class="heroNameRight"> <?php echo $heroinformation['heroName']; ?> </h2>
			<img class="imageright" src="<?php echo $heroinformation['heroImage']; ?>" />
			<h4 class="description"> <?php echo $heroinformation['heroDescription']; ?> </h4>
			<h4 class="heroPower"> <?php echo $heroinformation['heroPower']; ?> </h4>
			<form method="post" action="index.php?teamCat=<?php echo $heroinformation['teamId']; ?>&heroCat=<?php echo $heroinformation['heroId'];?>">
			<textarea placeholder = "leave a review:" name="submitComment" id="commentArea"rows="10" required></textarea>
			<input type="hidden" name="heroId" value="<?php echo $heroinformation['heroId']; ?>" />
			<button type="submit" name="submit" id="submitComment">Submit</button>
			</form>
			<?php
				foreach($reviews as $key => $review)
				{
					?>
					<h4 class="review"> <?php echo $review['ratingReview']; ?> </h4>
					<?php
				}
		}
		else
		{
			?>
			<h4>Please select a hero</h4>
			<?php
		}
		?>
	</div>

</div>
	
</body>
</html>