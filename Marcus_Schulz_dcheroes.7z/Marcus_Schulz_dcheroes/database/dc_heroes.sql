-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Gegenereerd op: 01 mrt 2019 om 19:56
-- Serverversie: 5.7.19
-- PHP-versie: 7.1.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dc heroes`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `hero`
--

CREATE TABLE `hero` (
  `heroId` int(3) NOT NULL COMMENT 'the unique heroId used as a parameter in the URL and fetched by PHP using the $_GET superblobal variable',
  `heroName` varchar(50) NOT NULL COMMENT 'the name of the hero, just a string',
  `heroDescription` text NOT NULL COMMENT 'some information of the hero, just a string',
  `heroPower` text NOT NULL,
  `heroImage` varchar(50) NOT NULL COMMENT 'the image of the hero is strored as a string. The actual image is strored on the server. Use the string as the source of the HTML img-tag.',
  `teamId` int(3) NOT NULL COMMENT 'this is the teamId. Used as a referenc to the team table.',
  `heroSmallDescription` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `hero`
--

INSERT INTO `hero` (`heroId`, `heroName`, `heroDescription`, `heroPower`, `heroImage`, `teamId`, `heroSmallDescription`) VALUES
(1, 'Batman', 'Description:\r\nBatman is a fictional superhero appearing in American comic books published by DC Comics. The character was created by artist Bob Kane and writer Bill Finger and first appeared in Detective Comics #27, in 1939. Originally named the \"Bat-Man\", the character is also referred to by such epithets as the Caped Crusader, the Dark Knight, and the World\'s Greatest Detective', 'Hero Power:\r\nBatmans heroPower is Strenght and Knowledge.', 'images/batman.jpg', 1, 'Small Description:\r\nThe Dark Knight is his other name.'),
(2, 'Joker', 'Description:\r\nThe Joker is a fictional supervillain created by Bill Finger, Bob Kane, and Jerry Robinson who first appeared in the debut issue of the comic book Batman (April 25, 1940), published by DC Comics. Credit for the Joker\'s creation is disputed; Kane and Robinson claimed responsibility for the Joker\'s design, while acknowledging Finger\'s writing contribution. Although the Joker was planned to be killed off during his initial appearance, he was spared by editorial intervention, allowing the character to endure as the archenemy of the superhero Batman.', 'Villain Power:\r\nJoker Villain Power is craziness and untraceable from the police and Batman.', 'images/smile.jpg', 4, 'Small Description:\r\nThe Joker is a crazy guy.'),
(3, 'Robin', 'Description:\r\nRobin is the name of several fictional superheroes appearing in American comic books published by DC Comics. The character was originally created by Bob Kane, Bill Finger, and Jerry Robinson, to serve as a junior counterpart to the superhero Batman. The character\'s first incarnation, Dick Grayson, debuted in Detective Comics #38 (April 1940). Conceived as a way to attract young readership, Robin garnered overwhelmingly positive critical reception, doubling the sales of the Batman titles. The early adventures of Robin included Star Spangled Comics #65–130 (1947–1952), which was the character\'s first solo feature. Robin made regular appearances in Batman related comic books and other DC Comics publications from 1940 through the early 1980s until the character set aside the Robin identity and became the independent superhero Nightwing. The team of Batman and Robin has commonly been referred to as the Caped Crusaders or Dynamic Duo.', 'Hero Power:\r\nRobins HeroPower is knowledge. Robin helps Batman tracking down enemies and fighting them. ', 'images/robin.png', 1, 'Small Description:\r\nHe is Batmans helper.'),
(4, 'Killer Croc', 'Description:\r\nThe character\'s real name is Waylon Jones, born with a form of atavism that imparted him with reptilian traits. He was raised by his aunt, an abusive alcoholic who called him names like \"lizardboy\" and \"reptilian freak\". Croc eventually killed his aunt and became a criminal in Gotham City. After committing several murders, he faced off against Batman and the new Robin, Jason Todd, who defeated him.\r\n\r\nIn these original, pre-Crisis appearances, Killer Croc resembled a powerfully built man covered entirely in green scales, but was still basically human in his facial proportions and build. He was also originally depicted as killing Jason Todd\'s parents (this was later retconned to make Two-Face their murderer). His appearance and personality have become increasingly bestial, explained in the comics that his disease has slowly robbed him of all identifiable human traits. In his most recent appearances, he has an elongated snout and tail.', 'Villain Power:\r\nKiller Crocs villain power is Strenght. ', 'images/killercroc.jpg', 3, 'Small Description:\r\nA large crocodile with a lot of power.'),
(5, 'Green Lantarn', 'Description:\r\nGreen Lantern is a 2011 American superhero film based on the DC Comics character of the same name. The film stars Ryan Reynolds, Blake Lively, Peter Sarsgaard, Mark Strong, Angela Bassett and Tim Robbins, with Martin Campbell directing a script by Greg Berlanti and comic book writers Michael Green and Marc Guggenheim, which was subsequently rewritten by Michael Goldenberg.[2] The film tells the story of Hal Jordan, a test pilot who is selected to become the first human member of the Green Lantern Corps. Hal is given a ring that grants him superpowers, and must confront Parallax, who threatens to upset the balance of power in the universe.', 'Hero Power:\r\nStrengt, Knowledge', 'images/greenlantarn.jpg', 5, 'Small Description:\r\nYou can recognize him really easy.'),
(6, 'Bane', 'Description:\r\nBane is a fictional supervillain appearing in American comic books published by DC Comics. Created by Dennis O\'Neil, Chuck Dixon, Doug Moench and Graham Nolan, he first appeared in Batman: Vengeance of Bane #1 (January 1993). The character is an adversary of the superhero Batman and belongs to the collective of enemies that make up his rogues gallery. With a mix of brute strength and exceptional intelligence, Bane is often credited as being the only villain to have broken the bat.', 'Villain Power:\r\nKnowledge, Strenght, has a lot of criminals in his team.', 'images/bane.jpg', 3, 'Small Description:\r\nAn high voice but really strong.'),
(7, 'Two Face', 'Description:\r\nTwo-Face (Harvey Dent) is a fictional supervillain appearing in comic books published by DC Comics, commonly as an adversary of the superhero Batman. The character was created by Bob Kane and Bill Finger and first appeared in Detective Comics #66 (August 1942). As one of Batman\'s most enduring enemies, Two-Face belongs to the collective of adversaries that make up Batman\'s rogues gallery.', 'Villain Power:\r\nKnowledge, Plays games.', 'images/twoface.jpg', 2, 'Small Description:\r\nHe was made by the Joker.'),
(8, 'Harley Quinn', 'Description:\r\nHarley Quinn (full name: Dr. Harleen Frances Quinzel, MD) is a fictional villain appearing in comic books published by DC Comics. The character was created by Paul Dini and Bruce Timm, and first appeared in Batman: The Animated Series in September 1992. She later appeared in DC Comics\'s Batman comic books, with the character\'s first comic book appearance in The Batman Adventures #12 (September 1993). In her depictions she has been portrayed as a Physician Psychiatrist (MD) and as a Psychologist (PhD). Medical Doctor (MD) physician being the more accurate label as she can prescribe medications and sees patients in an asylum wearing a white lab coat.', 'Villain Power:\r\nFlexible, has the Joker on her site.', 'images/quin.jpg', 4, 'Small Description:\r\nJokers girlfriend.'),
(9, 'Mr Penguin', 'Description:\r\nThe Penguin (Oswald Chesterfield Cobblepot) is a fictional supervillain appearing in comic books published by DC Comics, commonly as an adversary of the superhero Batman. The character made his first appearance in Detective Comics #58 (December 1941) and was created by Bob Kane and Bill Finger. The Penguin is one of Batman\'s most enduring enemies and belongs to the collective of adversaries that make up Batman\'s rogues gallery.', 'Villain Power:\r\nKnowledge, has a lot of penguins in his team that can explode.', 'images/penguin.jpg', 3, 'Small Description:\r\nHe looks like a penguin.'),
(10, 'Cat Woman', 'Description:\r\nCatwoman is a fictional character created by Bill Finger and Bob Kane who appears in American comic books published by DC Comics, commonly in association with superhero Batman. The character made her debut as the Cat in Batman #1 (June 1940), and her real name is Selina Kyle. She is Batman\'s most enduring love interest and is known for her complex love-hate relationship with him.', 'Villain Power:\r\nKnowledge, Sneaky.', 'images/cat.png', 3, 'Small Description:\r\nFast and Deadly.'),
(11, 'Superman', 'Description:\r\nSuperman is a fictional superhero appearing in American comic books published by DC Comics. Created by writer Jerry Siegel and artist Joe Shuster, the character first appeared in Action Comics #1 on April 18, 1938. Superman regularly appears in comic books published by DC Comics and has been adapted to radio shows, newspaper strips, television shows, movies, and video games.', 'Hero Power:\r\nStrenght, Knowledge, Can fly.', 'images/superman.jpg', 5, 'Small Description:\r\nHe is a big guy with a lot of power.'),
(12, 'Flash', 'Description: \r\nThe Flash (or simply Flash) is the name of several superheroes appearing in American comic books published by DC Comics. Created by writer Gardner Fox and artist Harry Lampert, the original Flash first appeared in Flash Comics #1 (cover date January 1940/release month November 1939).[1] Nicknamed the \"Scarlet Speedster\", all incarnations of the Flash possess \"super speed\", which includes the ability to run, move, and think extremely fast, use superhuman reflexes, and seemingly violate certain laws of physics.', 'Hero Power:\r\nSpeed, Knowledge.', 'images/flash.jpg', 5, 'Small Description:\r\nHe is faster then the lightning.'),
(13, 'Riddler', 'Description:\r\nThe Riddler (Edward Nigma or Nygma) is a fictional supervillain appearing in comic books published by DC Comics, created by Bill Finger and Dick Sprang. He first appeared in Detective Comics #140 (October 1948). The character is commonly depicted as a criminal mastermind in Gotham City who takes delight in incorporating riddles and puzzles into his schemes, leaving them as clues for the authorities to solve. The Riddler is one of the most enduring enemies of superhero Batman and belongs to the collective of adversaries that make up his rogues gallery.', 'Villain Power:\r\nKnowledge, Play games.', 'images/riddler.jpg', 2, 'Small Description:\r\nHe always has some riddles for you.'),
(14, 'Mr Freeze', 'Description:\r\nMr. Freeze (Victor Fries) is a fictional character (mostly a supervillain) appearing in American comic books published by DC Comics, commonly as an adversary of superhero Batman, created by writer Dave Wood and artist Sheldon Moldoff. The character first appeared in Batman #121 (February 1959), where he is known as Mr. Zero. Mr. Freeze is one of Batman\'s most enduring enemies and belongs to the collective of adversaries that make up Batman\'s rogues gallery.', 'Villain Power:\r\nCan freeze everything, Strenght.', 'images/freeze.png', 2, 'Small Description:\r\nMr Freeze always stays frosty.'),
(15, 'Clayface', 'Description:\r\nClayface is an alias used by several fictional supervillains appearing in American comic books published by DC Comics. Most incarnations of the character possess clay-like bodies and shape-shifting abilities, and all of them have been depicted as adversaries of the superhero Batman. In 2009, Clayface was ranked as IGN\'s 73rd Greatest Comic Book Villain of All Time.', 'Villain Power:\r\nCan turn into everything with his clay. ', 'images/clayface.jpg', 2, 'Small Description:\r\nHe can change into anything with his clay.'),
(16, 'Poison ivy', 'Description:\r\nPoison Ivy is a fictional supervillain/anti-hero appearing in comic books published by DC Comics, commonly in association with superhero Batman, created by Robert Kanigher and Sheldon Moldoff. The character made her debut in Batman #181 (June 1966). Her real name is Pamela Lillian Isley.', 'Villain Power:\r\nShe can use plants for everything, knowledge.', 'images/poison.jpg', 2, 'Small Description:\r\nUses plants for everything.'),
(17, 'Manbat', 'Description:\r\nMan-Bat (Robert Kirkland \"Kirk\" Langstrom) is a fictional supervillain appearing in comic books published by DC Comics, commonly as an adversary of the superhero Batman.', 'Villain Power:\r\nStrenght, Can fly.', 'images/manbat.jpg', 3, 'Small Description:\r\nHe is a real \'Batman\'.'),
(18, 'Mad Hatter', 'Description:\r\nThe Mad Hatter (Jervis Tetch) is a fictional supervillain appearing in comic books published by DC Comics, commonly as an adversary of the superhero Batman. He is modeled after the Hatter from Lewis Carroll\'s novel Alice\'s Adventures in Wonderland, a character often called the \"Mad Hatter\" in adaptations of Carroll.\r\n\r\nThe Mad Hatter is depicted as a scientist who invents and uses technological mind-controlling devices to influence and manipulate the minds of his victims. He is one of Batman\'s most enduring enemies and belongs to the collective of adversaries that make up Batman\'s rogues gallery.\r\n\r\nBenedict Samuel portrayed the character in the live action television series Gotham.', 'Villain Power:\r\nKnowledge, Play games, can fly a little bit.', 'images/Madhatter.png', 4, 'Small Description:\r\nLike the riddler, need some riddles?'),
(19, 'Scarecrow', 'Description:\r\nThe Scarecrow (Dr. Jonathan Crane) is a fictional supervillain appearing in American comic books published by DC Comics, created by Bill Finger, Bob Kane, and Jerry Robinson. The character first appeared in World\'s Finest Comics #3 (September, 1941). The self-proclaimed \"Master of Fear\" is commonly depicted as an obsessive ex-professor of psychology in Gotham City who uses a variety of experimental drugs and toxins to exploit the fears and phobias of his victims. He is one of the most enduring enemies of superhero Batman and belongs to the collective of adversaries that make up the Dark Knight\'s rogues gallery.', 'Villain Power:\r\nHas Venom that makes you scared of everything, knowledge.', 'images/scarecrow.jpg', 4, 'Small Description:\r\nHe scares you.'),
(20, 'Killer Moth', 'Desciption:\r\nKiller Moth (Drury Walker) is a fictional supervillain appearing in comic books published by DC Comics, commonly as an adversary of Batman. Killer Moth originally wore a garish costume of purple and green striped fabric, with an orange cape and a moth-like mask', 'Villain Power:\r\nHe can fly, strenght, harder to hit in the dark.', 'images/killermoth.jpg', 4, 'Small Description:\r\nLet the light be pad of your dead.'),
(21, 'Officer Gordon', 'James \"Jim\" Gordon is a fictional character appearing in American comic books published by DC Comics, most commonly in association with the superhero Batman. The character debuted in the first panel of Detective Comics #27 (May 1939), Batman\'s first appearance, where he is referred to simply as Commissioner Gordon. The character was created by Bill Finger and Bob Kane. Commissioner Gordon made his debut as an ally of Batman, making him the first Batman supporting character ever to be introduced.\r\n\r\nAs the police commissioner of Gotham City, Gordon shares Batman\'s deep commitment to ridding the city of crime. The character is typically portrayed as having full trust in Batman and is even somewhat dependent on him. In many modern stories, he is somewhat skeptical of Batman\'s vigilante methods, but nevertheless believes that Gotham needs him. The two have a mutual respect and tacit friendship. Gordon is the father or adoptive father (depending on the continuity) of Barbara Gordon, the first modern Batgirl and the information broker Oracle. Jim Gordon also has a son, James Gordon Jr., who first appeared in Batman: Year One.', 'Hero power:\r\nKnowledge, Helps Batman with a lot of police officers ', 'images/gordon.jpg', 1, 'Small Description:\r\nA high ranked police officer.'),
(22, 'Alfred Pennyworth', 'Alfred, most commonly (but not originally) named in full as Alfred Thaddeus Crane Pennyworth, is a fictional character appearing in American comic books published by DC Comics, most commonly in association with the superhero Batman.\r\n\r\nPennyworth is depicted as Bruce Wayne\'s loyal and tireless butler, housekeeper, legal guardian, best friend, aide-de-camp, and surrogate father figure following the murders of Thomas and Martha Wayne. As a classically trained British actor and an ex-Special Operations Executive operative of honor and ethics with connections within the intelligence community, he has been called \"Batman\'s batman\". He serves as Bruce\'s moral anchor while providing comic relief with his sarcastic and cynical attitude which often adds humor to dialogue with Batman. A vital part of the Batman mythos, Alfred was nominated for the Wizard Fan Award for Favorite Supporting Male Character in 1994.\r\n\r\nIn non-comics media, the character has been portrayed by noted actors William Austin, Eric Wilton, Michael Gough, Michael Caine, and Jeremy Irons on film and by Alan Napier, Efrem Zimbalist, Jr., Ian Abercrombie, David McCallum, and Sean Pertwee on television.', 'Hero power:\r\nHe is Batmans butler, he helps batman to prepare for a fight.\r\n', 'images/alfred.jpg', 1, 'Small Description:\r\nBatmans Butler.'),
(23, 'Barbara Gordon', 'Barbara Gordon is a fictional superhero appearing in American comic books published by DC Comics, commonly in association with the superhero Batman. The character was created by William Dozier, Julius Schwartz, and Carmine Infantino. At the request of the producers of the 1960s Batman television series, DC editor Schwartz called for a new female counterpart to the superhero Batman that could be introduced into publication and the third season of the show simultaneously. The character subsequently made her first comic book appearance as Batgirl in Detective Comics #359, titled \"The Million Dollar Debut of Batgirl!\" (January 1967), by writer Gardner Fox and artist Carmine Infantino.', 'Hero power:\r\nKnowledge.', 'images/barbara.png', 1, 'Small Description:\r\nA female hero.'),
(24, 'Wonder Woman', 'Description:\r\nOne of the most beloved and iconic DC Super Heroes of all time, Wonder Woman has stood for nearly eighty years as a symbol of truth, justice and equality to people everywhere. Raised on the hidden island of Themyscira, also known as Paradise Island, Diana is an Amazon, like the figures of Greek legend, and her people\'s gift to humanity.', 'Hero Power:\r\nSpeed, Knowledge.', 'images/wonderwoman.jpg', 5, 'Small Description:\r\nNot superman but wonder woman.'),
(25, 'Jay Garrick', 'Description:\r\nA founding member of the Justice Society of America—whose ranks include Green Lantern (Alan Scott), Hawkman, Hawkgirl, Wildcat, Power Girl and more—Jay was one of the first super heroes of Earth-2, a parallel world to the main DC Universe and home to the heroes of the Golden Age. As the Flash, Jay battled many super-criminals and saved the world alongside his friends numerous times. But he forever changed not only his world, but all worlds when he met his Earth-1 counterpart, Barry Allen. This famous meeting of the Flash of Two Worlds bridged the gap between realities and led to many team-ups, alignments and friendships between the heroes of both Earths. Together, the Flashes would join forces to battle Zoom, the Reverse-Flash, and many other super-villains.', 'Hero Power:\r\nSpeed, Knowledge, Strenght.', 'images/jay.jpg', 5, 'Small Description:\r\nMember of the Justice Society of America.');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `rating`
--

CREATE TABLE `rating` (
  `ratingId` int(3) NOT NULL COMMENT 'unique rating is, auto incremented',
  `heroId` int(3) NOT NULL COMMENT 'the heroId used as reference to the hero table, can''t be unique in thie table',
  `ratingDate` datetime NOT NULL COMMENT 'the date of this rating. Dates are presented as an integer (timestamp) and displayed as a human readable date and time string using the PHP strftime() function',
  `ratingReview` text NOT NULL COMMENT 'a textual review added by the user\\nthe form where the user can rate the hero by using stars (radio-buttons)'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `rating`
--

INSERT INTO `rating` (`ratingId`, `heroId`, `ratingDate`, `ratingReview`) VALUES
(1, 7, '2019-02-25 14:25:53', 'asasasa\r\nsass\r\nasa\r\nsass\r\n\r\n\r\nsasasasas'),
(2, 7, '2019-02-25 14:26:19', 'hehe, het lijkt te werken...'),
(3, 10, '2019-02-26 08:53:06', 'Test Test Test'),
(4, 10, '2019-02-26 23:31:13', '1231'),
(5, 10, '2019-02-26 23:34:16', '1231'),
(6, 10, '2019-02-26 23:47:10', '1231'),
(7, 10, '2019-02-26 23:48:00', '1231'),
(8, 10, '2019-02-26 23:48:29', '1231'),
(9, 10, '2019-02-26 23:49:27', '1231'),
(10, 1, '2019-08-23 00:00:00', 'Hoi'),
(11, 3, '2019-02-27 11:30:06', '..d.sd..sd'),
(12, 3, '2019-02-27 11:32:07', '..d.sd..sd'),
(13, 3, '2019-02-27 11:32:12', '..d.sd..sd'),
(14, 22, '2019-02-27 11:37:11', 'wrqwerwe'),
(15, 22, '2019-02-27 11:37:15', 'wrqwerwe'),
(16, 22, '2019-02-27 11:39:35', 'wrqwerwe'),
(17, 1, '2019-02-27 11:39:40', '12331'),
(18, 1, '2019-02-27 11:46:40', '12331'),
(19, 1, '2019-02-27 11:47:01', '12331'),
(20, 1, '2019-02-27 11:47:04', '12331'),
(21, 1, '2019-02-27 11:47:17', '12331'),
(22, 1, '2019-02-27 12:02:01', '12331'),
(23, 1, '2019-02-27 12:02:03', '12331'),
(24, 3, '2019-02-28 08:46:57', 'eqwqweqwewqqe'),
(25, 2, '2019-02-28 08:47:39', 'wqeqweqw'),
(26, 19, '2019-02-28 17:20:31', 'geweldig ventje dit'),
(27, 2, '2019-02-28 17:25:46', 'ertyuiopiugsa'),
(28, 2, '2019-02-28 17:25:48', 'ertyuiopiugsa'),
(29, 22, '2019-02-28 17:47:31', '12312'),
(30, 8, '2019-02-28 22:17:40', '12312312312'),
(31, 20, '2019-02-28 22:44:33', 'e12312312'),
(32, 20, '2019-02-28 22:44:49', 'e12312312'),
(33, 20, '2019-02-28 22:44:53', 'ggg'),
(34, 4, '2019-03-01 09:45:06', '444'),
(35, 4, '2019-03-01 09:46:33', '444'),
(36, 4, '2019-03-01 09:47:25', '444'),
(37, 4, '2019-03-01 09:52:23', '444'),
(38, 4, '2019-03-01 09:53:05', '444'),
(39, 4, '2019-03-01 10:00:53', '444'),
(40, 11, '2019-03-01 11:23:33', 'good'),
(41, 11, '2019-03-01 11:29:02', 'good'),
(42, 21, '2019-03-01 12:08:29', 'weqqweewqqwe'),
(43, 14, '2019-03-01 13:06:41', 'dwerwe'),
(44, 16, '2019-03-01 13:08:00', 'fghgfdasfgs'),
(45, 16, '2019-03-01 13:10:56', 'fghgfdasfgs'),
(46, 5, '2019-03-01 13:11:05', '2343423'),
(47, 5, '2019-03-01 13:15:05', '2343423'),
(48, 1, '2019-03-01 13:37:44', 'gjogyio90w=-'),
(49, 1, '2019-03-01 20:40:21', 'gjogyio90w=-'),
(50, 9, '2019-03-01 20:43:56', '2312'),
(51, 9, '2019-03-01 20:43:58', 'dsadsad'),
(52, 4, '2019-03-01 20:44:02', 'dasdasdsda'),
(53, 3, '2019-03-01 20:45:57', 'thic'),
(54, 13, '2019-03-01 20:53:06', 'rtytgfdfssdf');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `team`
--

CREATE TABLE `team` (
  `teamId` int(3) NOT NULL COMMENT 'unique teamId can be used as a parameter in the URL and fetched using the $_GET variable',
  `teamName` varchar(50) NOT NULL COMMENT 'team name, just an ordinary string',
  `teamDescription` text NOT NULL COMMENT 'team description, just a string',
  `teamImage` varchar(100) NOT NULL COMMENT 'team image, stored as a string and used with the source of the HTML-tag'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `team`
--

INSERT INTO `team` (`teamId`, `teamName`, `teamDescription`, `teamImage`) VALUES
(1, 'Batmans Squad', 'Batmans teammates', 'images/logo.jpg'),
(2, 'Riddlers Squad', 'Riddlers Squad', 'images/logo2.jpg'),
(3, 'Pinguins Squad', 'Pinguins Squad', 'images/logo3.jpg'),
(4, 'Jokers Squad', 'Jokers squad', 'images/logo4.jpg'),
(5, 'Other Heroes', 'Others heroes', 'images/logo5.jpg');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `hero`
--
ALTER TABLE `hero`
  ADD PRIMARY KEY (`heroId`);

--
-- Indexen voor tabel `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`ratingId`);

--
-- Indexen voor tabel `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`teamId`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `hero`
--
ALTER TABLE `hero`
  MODIFY `heroId` int(3) NOT NULL AUTO_INCREMENT COMMENT 'the unique heroId used as a parameter in the URL and fetched by PHP using the $_GET superblobal variable', AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT voor een tabel `rating`
--
ALTER TABLE `rating`
  MODIFY `ratingId` int(3) NOT NULL AUTO_INCREMENT COMMENT 'unique rating is, auto incremented', AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT voor een tabel `team`
--
ALTER TABLE `team`
  MODIFY `teamId` int(3) NOT NULL AUTO_INCREMENT COMMENT 'unique teamId can be used as a parameter in the URL and fetched using the $_GET variable', AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
